package com.example.posturewatcherapp;

import android.content.Intent;
import android.os.Bundle;

import com.github.mikephil.charting.components.AxisBase;
import com.github.mikephil.charting.components.Description;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.components.YAxis;
import com.github.mikephil.charting.data.BarData;
import com.github.mikephil.charting.formatter.IndexAxisValueFormatter;
import com.github.mikephil.charting.formatter.ValueFormatter;
import com.github.mikephil.charting.interfaces.datasets.IBarDataSet;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.os.Environment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.github.mikephil.charting.charts.BarChart;

import org.jetbrains.annotations.Nullable;
import android.graphics.Color;
import android.os.Bundle;
//import android.support.v9.app.ActionBarActivity;

import com.github.mikephil.charting.charts.BarChart;
import com.github.mikephil.charting.data.BarData;
import com.github.mikephil.charting.data.BarDataSet;
import com.github.mikephil.charting.data.BarEntry;
import com.github.mikephil.charting.utils.ColorTemplate;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;


public class GraphActivity extends AppCompatActivity {
    private BarChart chart;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_graph);

        int count0 = 0;
        int count1 = 0;
        int count2 = 0;
        int count3 = 0;
        int count4 = 0;
        int count5 = 0;

        String readFromFilePath = Environment.getExternalStorageDirectory().getAbsolutePath() + "/Download/";



        File readFromFile = new File(readFromFilePath, "readFromFile.txt");

        //int[] weeklyData = new int[6];
        Scanner scan = null;
        try {
            scan = new Scanner(readFromFile);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        String fileString = "";
        while (scan.hasNextLine()) {

            String nextString = scan.nextLine();

            if (nextString.equals("0")) {
                count0++;
            }
            else if (nextString.equals("1")) {
                count1++;
            }
            else if (nextString.equals("2")) {
                count2++;
            }
            else if (nextString.equals("3")) {
                count3++;
            }
            else if (nextString.equals("4")) {
                count4++;
            }
            else if (nextString.equals("5")) {
                count5++;
            }
        }
        scan.close();

        BarChart chart = (BarChart) findViewById(R.id.chart);

        //BarData data = new BarData(getXAxisValues(), getDataSet());

        IBarDataSet set1 = getDataSet(count0, count1, count2, count3, count4, count5);

        ArrayList<IBarDataSet> dataSets = new ArrayList<IBarDataSet>();
        Description theDesc = new Description();
        theDesc.setText("");
        dataSets.add(set1);

        BarData data = new BarData(dataSets);

        data.setValueTextSize(10f);
        data.setBarWidth(.9f);

        chart.setTouchEnabled(false);
        chart.setData(data);
        chart.setDescription(theDesc);

        //chart.setData(data);

        chart.animateXY(2000, 2000);
        ArrayList<String> xAxisLables = new ArrayList();
        //xAxisLables.add("");
        xAxisLables.add("perfect");
        xAxisLables.add("lean forward");
        xAxisLables.add("lean left");
        xAxisLables.add("lean backward");
        xAxisLables.add("lean right");


        chart.getXAxis().setValueFormatter(new IndexAxisValueFormatter(xAxisLables));
        chart.setFitBars(true);
        chart.invalidate();

    }

    private IBarDataSet getDataSet(int count0, int count1, int count2, int count3, int count4, int count5) {
        List<BarEntry> theList = new ArrayList<BarEntry>(); // y vals

        BarEntry v1e1 = new BarEntry(1, count1);
        BarEntry v1e2 = new BarEntry(2, count2);
        BarEntry v1e3 = new BarEntry(3, count3);
        BarEntry v1e4 = new BarEntry(4, count4);
        //BarEntry v1e5 = new BarEntry(5, count5);
        BarEntry v1e0 = new BarEntry(0, count0);

        theList.add(v1e0);
        theList.add(v1e1);
        theList.add(v1e2);
        theList.add(v1e3);
        theList.add(v1e4);
        //theList.add(v1e5);
        //theList.add(v1e6);


        BarDataSet set1 = new BarDataSet(theList, "Instances of different types of bad posture");
        set1.setColors(ColorTemplate.VORDIPLOM_COLORS);

        //ArrayList<IBarDataSet> dataSets = new ArrayList<IBarDataSet>();
        //dataSets.add(set1);

        return set1;
    }

    public void onClick(View view) {
        Intent i = new Intent(GraphActivity.this, LeftGraphActivity.class);
        startActivity(i);
    }
}