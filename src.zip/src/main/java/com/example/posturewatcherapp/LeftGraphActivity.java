package com.example.posturewatcherapp;

import android.content.Intent;
import android.os.Bundle;

import com.github.mikephil.charting.charts.BarChart;
import com.github.mikephil.charting.charts.LineChart;
import com.github.mikephil.charting.components.Description;
import com.github.mikephil.charting.data.BarData;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.LineData;
import com.github.mikephil.charting.data.LineDataSet;
import com.github.mikephil.charting.formatter.IndexAxisValueFormatter;
import com.github.mikephil.charting.interfaces.datasets.IBarDataSet;
import com.github.mikephil.charting.interfaces.datasets.ILineDataSet;
import com.github.mikephil.charting.utils.ColorTemplate;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.os.Environment;
import android.view.View;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class LeftGraphActivity extends AppCompatActivity {
    private LineChart chart;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_left_graph);
        //Toolbar toolbar = findViewById(R.id.toolbar);
        //setSupportActionBar(toolbar);

        int count0 = 0;
        int countBad = 0;

        int lines = 0;


        String readFromFilePath = Environment.getExternalStorageDirectory().getAbsolutePath() + "/Download/";
        File readFromFile = new File(readFromFilePath, "readFromFile.txt");



        //int[] weeklyData = new int[6];
        Scanner scan2 = null;
        try {
            scan2 = new Scanner(readFromFile);
            while(scan2.hasNextLine()) {
                scan2.nextLine();
                lines++;
            }
            scan2.close();

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }

        Scanner scan = null;
        try {
            scan = new Scanner(readFromFile);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }



        int weeks = 5;
        int entries = lines / 5; //70
        int count = 0;
        int weekNum = 0;
        int[] good = new int[weeks];
        int[] bad = new int[weeks];


        while (scan.hasNextLine()) {
            String nextString = scan.nextLine();


            if (nextString.equals("0")) {
                count0++;
            }
            else {
                countBad++;
            }

            count++;

            if (count == entries) {
                good[weekNum] = count0;
                bad[weekNum] = countBad;
                count0 = 0;
                countBad = 0;
                weekNum++;
                count = 0;
            }

            if (weekNum == weeks) {
                break;
            }
        }

        scan.close();




        LineChart chart = (LineChart) findViewById(R.id.lineChart);

        List<Entry> lineEntriesGood = new ArrayList<Entry>();
        List<Entry> lineEntriesBad = new ArrayList<Entry>();


        for (int i = 0; i < weeks; i++) {
            lineEntriesGood.add(new Entry(i, good[i]));
            lineEntriesBad.add(new Entry(i, bad[i]));
            //System.out.println("good = "+good[i]);
            //System.out.println("bad = "+bad[i]);
            //System.out.println("i = "+i);

        }

        LineDataSet goodSet = new LineDataSet(lineEntriesGood, "Good posture");
        LineDataSet badSet = new LineDataSet(lineEntriesBad, "Bad posture");

        goodSet.setColors(ColorTemplate.rgb("00FF80"));
        badSet.setColors(ColorTemplate.rgb("FF00FF"));


        ArrayList<ILineDataSet> dataSets = new ArrayList<ILineDataSet>();
        Description theDesc = new Description();
        theDesc.setText("");
        dataSets.add(goodSet);
        dataSets.add(badSet);

        LineData data = new LineData(dataSets);

        //data.setValueTextSize(10f);

        chart.setTouchEnabled(false);
        chart.setData(data);
        chart.setDescription(theDesc);

        chart.animateXY(2000, 2000);
        ArrayList<String> xAxisLables = new ArrayList();
        //xAxisLables.add("");
        /*xAxisLables.add("1");
        xAxisLables.add("2");
        xAxisLables.add("3");
        xAxisLables.add("4");
        xAxisLables.add("5");*/


        chart.getXAxis().setValueFormatter(new IndexAxisValueFormatter(xAxisLables));
        chart.invalidate();

    }

    public void onClick(View view) {
        Intent i = new Intent(LeftGraphActivity.this, GraphActivity.class);
        startActivity(i);
    }
}