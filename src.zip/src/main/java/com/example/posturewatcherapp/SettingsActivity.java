package com.example.posturewatcherapp;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.hardware.usb.UsbDeviceConnection;
import android.hardware.usb.UsbManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.DocumentsContract;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.preference.Preference;
import androidx.preference.PreferenceFragmentCompat;
import androidx.preference.PreferenceManager;

import com.example.posturewatcherapp.ui.login.LoginActivity;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.OutputStream;
import java.net.URI;
import java.util.Scanner;

public class SettingsActivity extends AppCompatActivity {

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.settings_activity);
        if (savedInstanceState == null) {
            getSupportFragmentManager()
                    .beginTransaction()
                    .replace(R.id.linearLayout, new SettingsFragment())
                    .commit();
        }
        ActionBar actionBar = getSupportActionBar();
        if (actionBar != null) {
            actionBar.setDisplayHomeAsUpEnabled(true);
        }

        /*// Find all available drivers from attached devices.
        UsbManager manager = (UsbManager) getSystemService(Context.USB_SERVICE);
        List<UsbSerialDriver> availableDrivers = UsbSerialProber.getDefaultProber().findAllDrivers(manager);
        if (availableDrivers.isEmpty()) {
            return;
        }

        // Open a connection to the first available driver.
        UsbSerialDriver driver = availableDrivers.get(0);
        UsbDeviceConnection connection = manager.openDevice(driver.getDevice());
        if (connection == null) {
            // add UsbManager.requestPermission(driver.getDevice(), ..) handling here
            return;
        }

        UsbSerialPort port = driver.getPorts().get(0); // Most devices have just one port (port 0)
        port.open(connection);
        port.setParameters(115200, 8, UsbSerialPort.STOPBITS_1, UsbSerialPort.PARITY_NONE);*/
    }

    public static class SettingsFragment extends PreferenceFragmentCompat {
        @Override
        public void onCreatePreferences(Bundle savedInstanceState, String rootKey) {
            setPreferencesFromResource(R.xml.root_preferences, rootKey);
        }
    }

    public void onClick(View view) {
        String postureThresh = PreferenceManager.getDefaultSharedPreferences(this).getString("posture", "100");
        String oversittingThresh = PreferenceManager.getDefaultSharedPreferences(this).getString("oversitting", "100");
        String sleepThresh = PreferenceManager.getDefaultSharedPreferences(this).getString("sleep", "10000");
        boolean vibrationMode = PreferenceManager.getDefaultSharedPreferences(this).getBoolean("vibrationMode", true);

        String vibrationModeString = "";
        if (vibrationMode) {
            vibrationModeString = "True";
        }
        else {
            vibrationModeString = "False";
        }

        // internal storage -> download
        String dir = Environment.getExternalStorageDirectory().getAbsolutePath() + "/Download/";
        //String dir = getFilesDir().toString();
        //System.out.println("file dir = "+dir);
        String FILENAME = "postureTest.txt";
        //String FILENAME = "readFromFile.txt";
        File file = new File (dir, FILENAME);
        try {
            FileOutputStream out = new FileOutputStream(file, false);
            out.write(("bluetoothOn=True\nvibMode="+vibrationModeString +
                    "\nsleepThresh=" + sleepThresh + "\noversittingThresh=" + oversittingThresh +
                    "\nbadPosThresh=" + postureThresh).getBytes());
            /*out.write(("1\n2\n3\n4\n5\n1\n2\n3\n4\n5\n0\n1\n1\n1\n1\n1\n0\n1\n1\n1\n2\n2\n2\n2\n2\n0\n2\n2\n2\n0\n2\n0\n0\n0\n0\n0\n2\n2\n2\n4\n4\n4\n4\n4\n4\n4\n4\n4\n4\n4\n4\n4\n4\n4\n4\n3\n3\n3\n" +
                    "0\n0\n0\n0\n0\n0\n0\n0\n0\n0\n0\n0\n0\n0\n5\n5\n5\n5\n5\n0\n0\n0\n0\n0\n5\n5\n5\n5\n1\n1\n1\n1\n5\n5\n5\n5\n1\n1\n1\n1\n5\n5\n5\n5\n1\n1\n1\n1\n5\n5\n5\n5\n1\n1\n1\n1\n" +
                    "1\n2\n3\n4\n5\n1\n2\n3\n4\n5\n1\n0\n0\n2\n0\n3\n4\n5\n1\n0\n0\n0\n2\n3\n4\n5\n1\n2\n0\n0\n0\n0\n3\n0\n0\n0\n0\n0\n4\n5\n1\n2\n3\n4\n0\n0\n5\n1\n2\n3\n4\n5\n1\n2\n3\n4\n5\n1\n1\n2\n2\n2\n2\n2\n2\n2\n2\n2\n" +
                    "2\n2\n2\n4\n4\n4\n4\n4\n4\n4\n4\n1\n2\n3\n4\n5\n1\n2\n3\n4\n5\n1\n2\n3\n4\n5\n1\n2\n3\n4\n5\n1\n2\n3\n4\n5\n1\n2\n3\n4\n5\n0\n0\n1\n2\n3\n4\n5\n1\n2\n3\n4\n5\n" +
                    "1\n2\n3\n4\n5\n1\n2\n3\n4\n5\n0\n0\n0\n1\n2\n3\n4\n5\n1\n2\n3\n4\n5\n1\n2\n3\n4\n5\n1\n2\n0\n0\n0\n0\n0\n3\n4\n5\n1\n2\n3\n4\n5\n1\n2\n3\n4\n5\n1\n1\n2\n2\n2\n2\n2\n2\n2\n2\n2\n" +
                    "1\n2\n3\n4\n5\n1\n2\n3\n4\n5\n1\n2\n3\n0\n0\n0\n0\n0\n0\n4\n5\n1\n2\n3\n4\n0\n0\n0\n0\n0\n0\n0\n5\n1\n2\n3\n4\n5\n1\n2\n3\n4\n5\n1\n2\n3\n4\n5\n1\n2\n3\n4\n5\n1\n1\n2\n2\n2\n2\n2\n2\n2\n2\n2\n" +
                    "1\n2\n3\n4\n5\n1\n2\n3\n4\n5\n1\n2\n3\n4\n5\n0\n0\n0\n0\n0\n0\n1\n2\n3\n4\n5\n1\n2\n3\n4\n5\n0\n0\n0\n0\n0\n0\n0\n0\n1\n2\n3\n4\n5\n1\n2\n3\n4\n5\n1\n2\n3\n4\n5\n0\n0\n0\n0\n0\n0\n1\n1\n2\n2\n2\n2\n2\n2\n2\n2\n2\n").getBytes());*/
            out.close();
            //System.out.println("file = " + file.toString());

            String readFromFilePath = Environment.getExternalStorageDirectory().getAbsolutePath() + "/Download/";
            File readFromFile = new File(readFromFilePath, "readFromFile.txt");

            //int[] weeklyData = new int[6];
            /*Scanner scan = new Scanner(readFromFile);
            String fileString = "";
            while (scan.hasNextLine()) {
                fileString = fileString + "\n" + scan.nextLine();
            } */
            Intent i = new Intent(SettingsActivity.this, GraphActivity.class);
            //i.putExtra("theString", fileString);
            startActivity(i);

        }
        catch (Exception e) {
            e.printStackTrace();
        }
        //System.out.println("vibrationMode = "+vibrationModeString);

    }
}